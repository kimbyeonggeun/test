let import_data = document.getElementById('import');


var i = 0;
function toggle_object(post_id) {
    i = i + post_id;
    var obj = document.getElementById('star');
    if (!obj) return;

    if (i % 2 != 0) {
        obj.style.background = "second_report/img/fav_Start_act.png";

    }
    else {
        obj.style.background = "second_report/img/fav_Start.png";
    }
}