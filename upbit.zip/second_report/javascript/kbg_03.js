// 현재가 - price
// 전일대비 증감% - chgrate
// 전일대비 증감량 - change
// 거래대금 - value

fetch("http://203.109.30.207:5655/kwansim", { method: 'GET' })
    .then(Result => Result.json())
    .then(jsonData => {
        // debugger
        for (var i = 0; i < jsonData.length; i += 1) {
            let tr = document.createElement("tr");
            let td = document.createElement("td");

            let star = document.createElement("td");
            let names = document.createElement("td");
            let price = document.createElement("td");
            let chgrate = document.createElement("td");
            let value = document.createElement("td");
            let kr = document.createElement('div');
            let en = document.createElement('div');
            let div1 = document.createElement('div');
            let div2 = document.createElement('div');
            let span = document.createElement('span');

            var star_class = 'star' + i;
            var toggle_func = 'toggle(' + i + ')';

            star.setAttribute('class', 'star');
            star.setAttribute('onclick', toggle_func);
            names.setAttribute('class', 'name');
            kr.setAttribute('class', 'kr');
            en.setAttribute('class', 'en');
            price.setAttribute('class', 'price');
            chgrate.setAttribute('class', 'chgrate');
            value.setAttribute('class', 'value');
            tr.setAttribute('class', 'data');
            span.setAttribute('class', 'unit');

            // 별
            tr.append(star);

            // 이름
            kr.innerText = jsonData[i].jmname;
            en.innerText = jsonData[i].shcode;
            names.append(kr, en);
            tr.append(names);

            // 현재가
            var priceText = jsonData[i].price;
            price.setAttribute('class', 'price');
            priceText = setColor(priceText, price);
            price.innerText = comma(priceText);
            tr.append(price);

            //전일대비

            // 증감 %
            var chgrateText = jsonData[i].chgrate;
            td.setAttribute('class', 'chgrate');
            chgrateText = setColor(chgrateText, div1);
            div1.innerText = comma(chgrateText) + "%";
            chgrate.append(div1);

            // 증감량
            var changeText = jsonData[i].change;
            changeText = setColor(changeText, div2)
            div2.innerText = comma(changeText);
            chgrate.append(div2);
            tr.append(chgrate);

            // 거래대금
            value.setAttribute('class', 'value');
            const text = Math.floor(Number(jsonData[i].value) / 1000000);
            value.innerText = comma(text);
            span.innerText = "백만";
            value.append(span);
            tr.append(value);

            // 삽입
            document.querySelector("#body").append(tr);

            // test용 라인
            var testline = jsonData[0].shcode;
            console.log(testline);
        }
        // left-container에 주식명과 현재가 삽입
        let jm = document.getElementsByClassName('jm')[0];
        let market = document.getElementsByClassName('market')[0];

        jm.innerText = jsonData[0].jmname + ' / ' + jsonData[0].shcode;
        market.innerText = comma(setColor(jsonData[0].price, market))+'원';
    }).catch(error => alert(error)
    );

// 즐겨찾기 별 이미지 변경
function toggle(param) {
    let element = document.getElementsByClassName('star')[param];
    const url = 'url("./img/fav_Start.png") 0px 3px / 80% no-repeat';
    const act_url = 'url("./img/fav_Start_act.png") 0px 3px / 80% no-repeat';

    if (element.style.background == url) {
        element.style.background = act_url;
    }
    else if (element.style.background == act_url) {
        element.style.background = url;
    }
    else {
        element.style.background = act_url;
    }
}

// 카테고리 클릭시 글 색상과 div밑부분에 라인 생성
function toggle_category(param) {
    const element = document.querySelectorAll('#category div');
    for (var i = 0; i < element.length; i += 1) {
        element[i].style.color = 'black';
        element[i].style.removeProperty('box-shadow');
        element[i].style.removeProperty('font-weight');
    }
    element[param].style.color = 'blue';
    element[param].style.boxShadow = 'inset 0 -3px 0 0px blue';
    element[param].style.fontWeight = 'bolder';
}

// 3자리마다 콤마 찍는 함수
function comma(param) {
    return param.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// setColor - 값의 증감에 따라 색 변경 및 String 자르기
// param - 받아오는 데이터, param2 - 데이터를 저장하는 태그의 class
function setColor(param, param2) {
    if (param.substring(0, 1) == "-") {                 // 감소
        param2.style.color = 'blue';
        return param.substring(1, param.length);
    } else if (param.substring(0, 1) == "+") {          // 증가
        param2.style.color = 'red';
        return param;
    } else {                                            // 증감 X
        param2.style.color = 'black';
        return '0';
    }
}

// setMarket - 오른쪽에서 주식을 클릭하면 왼쪽에 종목과 현재가격을 띄우는 함수
// 기본은 첫번째 종목인 LG유플러스
document.addEventListener('click', function(){
    // 주식명을 삽입할 태그 가져오기
    const jm = document.querySelector('.jm');
    const market = document.querySelector('.market');

    // 삽입할 데이터 가져오기
})

function setMarket() {

}

// 검색
// https://stickode.tistory.com/832 참고
document.addEventListener('DOMContentLoaded', function() {
    // 검색창 element를 id값으로 가져오기
    const payrollSearch = document.querySelector('#search');
    // 테이블의 tbody element를 id값으로 가져오기
    const payrollTable = document.querySelector('#table tbody');
    
    //검색창 element에 keyup 이벤트 세팅. 글자 입력 시 마다 발생.
    payrollSearch.addEventListener('keyup', function() {
    	 // 사용자가 입력한 검색어의 value값을 가져와 소문자로 변경하여 filterValue에 저장
    	const filterValue = payrollSearch.value.toLowerCase();
   		 // 현재 tbody안에 있는 모든 tr element를 가져와 rows에 저장
    	const rows = payrollTable.querySelectorAll('tr');
        
        //tr들 for문으로 순회
        for (var i = 0; i < rows.length; i++) {
            // 현재 순회중인 tr의 textContent를 소문자로 변경하여 rowText에 저장
            var rowText = rows[i].textContent.toLowerCase();
            // rowText가 filterValue를 포함하면, 해당 tr은 보여지게 하고, 그렇지 않으면 숨긴다.
            if (rowText.includes(filterValue)) {
                rows[i].style.display = '';
            } else {
                rows[i].style.display = 'none';
            }
        }
    });
});